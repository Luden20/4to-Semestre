#-*-coding:cp1252-*-
cad = input("Ingrese una cadena:... ")
res = cad.split()  # Divide la cadena en palabras utilizando el metodo split() y almacena el resultado en (res)
res = len(res)  # Calcula la longitud de la lista 'res', que representa el n�mero de palabras en la cadena
print(f"La frase tiene {res} palabras")
print("GRACIAS POR USAR ESTE PROGRAMA")
