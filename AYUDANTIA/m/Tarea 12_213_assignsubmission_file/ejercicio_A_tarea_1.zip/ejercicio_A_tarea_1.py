#--coding:cp1252--
#Danny Alajo, David Vallejo 
cad=input("Introduce una cadena de caracteres� ")
n=cad.count(" ")+1 #Calcula el n�mero de palabras al ingresar el usuario
print(f"La frase tiene {n} palabras")

