#-*-coding:cp1252-*-
#Elaborado por: Moreno Karol y Vizcaino Cielo
cad=0
total=0
cad=input("Introduce una cadena de caracteres...")
print("Impresi�n:")

cad= cad.split()
total= len(cad)
print(f"La frase tiene {total} palabras")
